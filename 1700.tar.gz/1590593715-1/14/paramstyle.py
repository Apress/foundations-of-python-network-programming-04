#!/usr/bin/env python
# Parameter style - Chapter 14 - paramstyle.py

import psycopg
print psycopg.paramstyle
