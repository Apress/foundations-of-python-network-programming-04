This archive contains the examples for:

Foundations of Python Network Programming (APress)

The examples for each chapter are in individual directories for that
chapter.

Please refer to the comments in the book's introduction for
information on running these examples and platform-specific notes.

If errors are found in the examples after the book goes to print,
updated examples will be posted here.

-- John Goerzen
   July 19, 2004
